# Design Guidelines: Anniversary Webpage

## Design Approach
**Existing Design Preservation**: This project has a complete romantic design that must be maintained. The guidelines document the existing aesthetic to ensure consistency during implementation.

## Core Design Elements

### Typography
- **Headings**: Dancing Script (700 weight) at 3em for romantic, handwritten feel
- **Body Text**: Quicksand (400-500 weights) at 1.2em for clean readability
- Font CDN: Google Fonts for both families

### Color Palette (Existing - DO NOT CHANGE)
- **Background**: Pure black (#000000)
- **Primary Accent**: Hot pink (#ff69b4) for main heading
- **Body Text**: Light purple (#d8b4f8)
- **Hearts Animation**: Baby blue (#89CFF0)
- **Footer**: Soft pink (#ffb6c1)

### Layout System
- **Spacing**: Use existing margins (60px top for heading, 25px for paragraphs, 50px for footer)
- **Widths**: Content at 85% width with auto margins for centering
- **Container**: max-width of 600px for media elements

### Component Library

**Floating Hearts Animation**:
- Fixed position overlay covering full viewport
- 20 animated hearts floating from bottom to top
- Random horizontal positioning (0-100vw)
- Random sizes (20-50px) and animation durations (5-10s)
- Opacity fades during upward float
- z-index: -1 (behind content)

**Content Blocks**:
- Semi-transparent backgrounds (rgba(255, 255, 255, 0.05))
- 20px padding with 15px border-radius
- Subtle drop shadows for depth
- Text shadow for better contrast on dark background

**Audio Player**:
- Replace YouTube embed with custom HTML5 audio element
- Width: 80%, max-width: 600px
- 25px top margin
- Rounded corners (15px border-radius)
- Glowing shadow effect using primary purple tones

**Footer**:
- Italic styling
- 50px bottom padding
- Centered text with soft glow effect

### Visual Effects
- **Text Shadows**: Glow effects on heading (#ff69b4 glow) and subtle shadows on body text
- **Box Shadows**: Soft shadows on content blocks and media elements
- **Animation**: Continuous heart float animation only - no hover effects or interactions

### Layout Structure
Single-page vertical flow:
1. Floating hearts background (full viewport, fixed)
2. Main heading with top spacing
3. Anniversary message in styled content block
4. Audio player (background music)
5. Footer message

**No multi-column layouts** - maintain simple centered vertical stack for intimate, focused reading experience.

### Images
No images required - design relies on emoji hearts (💖, 💙, 💋) and text content for visual interest.

## Critical Implementation Notes
- Maintain exact color values as specified
- Preserve animation timing and easing functions
- Keep semi-transparent overlays subtle
- Ensure responsive scaling maintains readability on mobile
- Audio should have native browser controls (no custom player needed)
- All text content must remain exactly as provided in original HTML