import { useEffect, useRef, useState } from "react";
import audioFile from "@assets/Jux - Nisiulizwe (Official Audio) [Visualizer]_1762610333061.mp3";

export default function Anniversary() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [showOverlay, setShowOverlay] = useState(true);

  useEffect(() => {
    const heartsContainer = document.querySelector(".hearts");
    if (!heartsContainer) return;

    for (let i = 0; i < 20; i++) {
      const heart = document.createElement("div");
      heart.classList.add("heart");
      heart.innerHTML = "💙";
      heart.style.position = "absolute";
      heart.style.left = Math.random() * 100 + "vw";
      heart.style.animationDuration = 5 + Math.random() * 5 + "s";
      heart.style.fontSize = 30 + Math.random() * 40 + "px";
      heart.style.animation = "float 8s infinite ease-in";
      heart.style.opacity = "0.9";
      heart.style.animationDelay = Math.random() * 5 + "s";
      heartsContainer.appendChild(heart);
    }
  }, []);

  const handleEnter = () => {
    setShowOverlay(false);
    if (audioRef.current) {
      audioRef.current.currentTime = 25;
      audioRef.current.play();
    }
  };

  return (
    <div className="min-h-screen bg-black text-center relative overflow-x-hidden">
      {showOverlay && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          <button
            onClick={handleEnter}
            className="text-6xl px-12 py-6 rounded-2xl font-bold transition-transform hover:scale-110 active:scale-95"
            style={{
              background: "linear-gradient(135deg, #ff69b4, #d8b4f8)",
              color: "#000",
              boxShadow: "0 0 30px rgba(255, 105, 180, 0.6)",
            }}
            data-testid="button-enter"
          >
            clicky 😊⏸
          </button>
        </div>
      )}

      <div className="hearts fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0"></div>

      <style>{`
        @keyframes float {
          0% { transform: translateY(100vh) scale(1); opacity: 0.8; }
          100% { transform: translateY(-10vh) scale(1.5); opacity: 0; }
        }
      `}</style>

      <h1
        className="mt-16 text-5xl md:text-6xl font-bold text-center relative z-10"
        style={{
          fontFamily: "'Dancing Script', cursive",
          color: "#ff69b4",
          textShadow: "0 0 12px rgba(255, 105, 180, 0.6)",
        }}
        data-testid="heading-anniversary"
      >
        Happy 1st Anniversary 💖
      </h1>

      <div
        className="w-[85%] mx-auto my-6 text-lg md:text-xl leading-relaxed p-5 rounded-2xl font-semibold relative z-10"
        style={{
          fontFamily: "'Patrick Hand', cursive",
          color: "#d8b4f8",
          background: "rgba(255, 255, 255, 0.05)",
          boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)",
          textShadow: "0 1px 2px rgba(0,0,0,0.5)",
        }}
        data-testid="text-message"
      >
        Happy 1st Anniversary msupa wangu 💖
        <br />
        <br />
        Melvin my love... Its been 1 year and 10 months and 9 days since we met
        and out of those, 1 year of officially dating (yes nahesabu adi hours),
        time flies... and just a reminder that you're still stuck with me. 😂
        <br />
        <br />
        Every moment with you has been a blessing and I'm so grateful to have
        you in my life and I wouldn't trade it for anything else in the world.
        It's a treasure.
        <br />
        <br />
        I love everything about you, your joyful and funny nature, your
        personality, your kindness, caring and loving heart and of course your
        handsomeness which is a huge bonus. 😜
        <br />
        <br />
        Here's to many more years of happiness, making memories and cherished
        moments together!
        <br />
        <br />
        Cheers to the journey we begun together 🥂 ml who still hasn't learned
        that im always right na haskii maneno, Love you anyway! you're very
        special to me (I mean mentally 😂). I could go on and on......
        <br />
        <br />
        I know you're smiling like crazy ju ya hizi mistari 😁
        <br />
        <br />
        I love you a lot 😘💖
        <br />– your one and only Fundi 💋
      </div>

      <div className="mt-6 flex flex-col items-center gap-4 relative z-10">
        <audio
          ref={audioRef}
          src={audioFile}
          loop
          autoPlay
          className="w-[80%] max-w-[600px] rounded-2xl"
          style={{
            boxShadow: "0 0 15px rgba(78, 33, 115, 0.4)",
          }}
          controls
          data-testid="audio-player"
        />
      </div>

      <footer
        className="mt-12 italic pb-12 relative z-10"
        style={{
          color: "#ffb6c1",
          textShadow: "0 0 8px rgba(0,0,0,0.3)",
        }}
        data-testid="text-footer"
      >
        💞 With love, from Fundi to Melvin 💞
      </footer>
    </div>
  );
}
